document.addEventListener("DOMContentLoaded", function() {
  const menuIcon = document.getElementById('menu-icon');
  const menuList = document.getElementById('menu-list');

  menuIcon.addEventListener('click', function() {
    menuList.classList.toggle('visible');
  });
});


const messages = ["Newbie", "Pemula", "Debu", "Trash", "Culai", "Cufu", "Semut"];
let messageIndex = 0;
let charIndex = 0;
const typingSpeed = 200; 
const erasingSpeed = 100; 
const delayBetweenMessages = 1000; 
const typingElement = document.getElementById("typing-effect");
const typingElemens = document.getElementById("typing-mobile");


function type() {
    if (charIndex < messages[messageIndex].length) {
        typingElement.textContent += messages[messageIndex].charAt(charIndex);
        typingElemens.textContent += messages[messageIndex].charAt(charIndex);
        charIndex++;
        setTimeout(type, typingSpeed);
    } else {
        setTimeout(erase, delayBetweenMessages);
    }
}

function erase() {
    if (charIndex > 0) {
        typingElement.textContent = messages[messageIndex].substring(0, charIndex - 1);
        typingElemens.textContent = messages[messageIndex].substring(0, charIndex - 1);
        charIndex--;
        setTimeout(erase, erasingSpeed);
    } else {
        messageIndex = (messageIndex + 1) % messages.length;
        setTimeout(type, typingSpeed);
    }
}


document.addEventListener("DOMContentLoaded", () => {
    setTimeout(type, delayBetweenMessages);
});

document.getElementById('try').addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('popup').classList.remove('hidden');
    document.getElementById('popup').scrollIntoView({ behavior: 'smooth', block: 'center' });
});

const chatBox = document.getElementById('chat-box');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');

document.getElementById('back-button').addEventListener('click', function() {
    document.getElementById('popup').classList.add('hidden');
});

sendButton.addEventListener('click', async () => {
  const message = messageInput.value;
  if (message.trim()) {
    chatBox.innerHTML += `<p class="user-message"><strong>You:</strong> ${message}</p>`;
    messageInput.value = '';
    const response = await fetch('/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message })
    });
    const data = await response.json();
    if (data.reply) {
      const reply = formatReply(data.reply);
      chatBox.innerHTML += `<p class="groq-message"><strong>AI:</strong> ${reply}</p>`;
    }
    chatBox.scrollTop = chatBox.scrollHeight;
  }
});

function formatReply(reply) {
  return reply;
}