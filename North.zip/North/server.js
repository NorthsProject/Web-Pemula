const express = require('express');
const path = require('path');
const app = express();

// Atur static file
app.use(express.static(path.join(__dirname, 'public')));

// Tambahkan middleware untuk parsing JSON
app.use(express.json());

// Array pesan demo yang beragam
const demoMessages = [
  "Hallo, ini adalah demo AI.",
  "Halo! Selamat datang di demo AI sederhana kami.",
  "Hai! Ada yang bisa saya bantu hari ini?",
  "Selamat datang! Apa yang ingin Anda ketahui tentang AI?",
  "Halo! Ini adalah contoh penggunaan AI dalam aplikasi chat.",
  "Demo AI ini disediakan hanya untuk keperluan demonstrasi.",
  "Apa kabar? Saya adalah contoh AI yang ramah."
];

// Fungsi untuk mendapatkan respons acak dari array pesan demo
function getRandomResponse() {
  const randomIndex = Math.floor(Math.random() * demoMessages.length);
  return demoMessages[randomIndex];
}

app.post('/chat', async (req, res) => {
  try {
    const aiResponse = getRandomResponse();
    res.json({ reply: aiResponse });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

// Jalankan server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server berjalan pada port ${PORT}`);
});

console.clear();
console.log('[SISTEM] Starting the server...');